#include "Random.h"

Rand g_rand1(1);
Rand g_rand2(2);
Rand g_rand3(3);
Rand g_rand4(4);

//-----------------------------------------------------------------------------
